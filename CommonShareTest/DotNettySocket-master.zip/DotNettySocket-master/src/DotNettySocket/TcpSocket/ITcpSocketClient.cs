﻿namespace Coldairarrow.DotNettySocket
{
    /// <summary>
    /// TcpSocket客户端
    /// </summary>
    public interface ITcpSocketClient : IBaseTcpSocketClient, ISendBytes, ISendString
    {

    }
}