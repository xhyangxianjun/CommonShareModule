﻿namespace Coldairarrow.DotNettySocket
{
    /// <summary>
    /// TcpSocket服务端
    /// </summary>
    public interface ITcpSocketServer : IBaseTcpSocketServer<ITcpSocketConnection>
    {

    }
}