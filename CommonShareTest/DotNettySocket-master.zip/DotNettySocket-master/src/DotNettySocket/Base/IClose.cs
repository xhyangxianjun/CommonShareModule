﻿namespace Coldairarrow.DotNettySocket
{
    /// <summary>
    /// 关闭接口
    /// </summary>
    public interface IClose
    {
        /// <summary>
        /// 关闭
        /// </summary>
        void Close();
    }
}