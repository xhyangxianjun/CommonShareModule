﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Common
{
    public class OrderService : IOrderService
    {
        public decimal CalculateFinalOrderSum(long userId, decimal originalSum)
        {
            return 666;
        }
    }
}
