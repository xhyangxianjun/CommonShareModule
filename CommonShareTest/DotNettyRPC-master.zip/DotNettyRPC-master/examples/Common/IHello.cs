﻿namespace Common
{
    public interface IHello
    {
        void SayHello(string msg);
    }
}
